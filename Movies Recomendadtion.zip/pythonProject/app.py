import streamlit as st

st.title('Movie Recommendation System')

